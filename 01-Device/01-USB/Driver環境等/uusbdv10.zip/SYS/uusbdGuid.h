/***************************************************

Copyright (c) 1999  kashiwano masahiro

Abstract:

    GUID for UUSBD.SYS
    
****************************************************/

#ifndef GUIDUUSBDH_INC
#define GUIDUUSBDH_INC

#include <initguid.h>

// {69910468-8802-11d3-ABC7-A756B2FDFB29} for UUSBD.SYS 
DEFINE_GUID(GUID_CLASS_UUSBD, 
0x69910468, 0x8802, 0x11d3, 0xab, 0xc7, 0xa7, 0x56, 0xb2, 0xfd, 0xfb, 0x29);

#endif // end, #ifndef GUIDUUSBDH_INC
