#include "setupapi.h"

PSP_INTERFACE_DEVICE_DETAIL_DATA GetDeviceDeatailData(LPGUID pGuid, int index);
TCHAR  *GetDeviceName(LPGUID pGuid, int index);
